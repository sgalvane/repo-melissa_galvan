package com.proyecto.proveedores.constants;

public class AppConstants {

    public static final String ACTUALIZACION_EXITOSA="Se ha actualizado correctamente";

    public static final String NO_EXISTE="No existe registro";

    public static final String ELIMINACION_EXITOSA="Se ha eliminado el producto";

    public static final String HA_SIDO_ELIMINADO="El producto ya ha sido eliminado";
}
